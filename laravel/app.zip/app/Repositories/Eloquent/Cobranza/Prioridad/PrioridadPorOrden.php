<?php

/**
 * Created by PhpStorm.
 * User: joaquin
 * Date: 10/05/17
 * Time: 22:38
 */
class PrioridadPorOrden
{

}