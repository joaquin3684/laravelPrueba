<?php
/**
 * Created by PhpStorm.
 * User: joaquin
 * Date: 25/04/17
 * Time: 16:07
 */

namespace App\Repositories\Eloquent\ABMS;

use App\Repositories\Contracts\abmInterface;
use App\Repositories\Eloquent\ABMS\RepositorioAbm;

class AbmUsuariosRepositorio
{

}